#include "AbsoluteOrRelativeTime.h"

extern class AbsoluteOrRelativeTime;

extern typedef AbsoluteOrRelativeTime wsnt__AbsoluteOrRelativeTimeType;